export type AccountStatus = 'active' | 'banned';

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  passwordSalt: string;
  createdAt: string; // ISO date string
  lastLoginAt: string; // ISO date string
  status: AccountStatus;
  sessionVersion: number; // incremented by admin to revoke active sessions
  maxAccessDays: number; // 365 days
  expiresAt: string; // ISO date string
}

export interface UserSession {
  userId: string;
  name: string;
  email: string;
  sessionVersion: number;
}

export interface AccessValidityInfo {
  daysUsed: number;
  daysRemaining: number;
  isExpired: number | boolean;
  percentageUsed: number;
  formattedExpiresAt: string;
  formattedCreatedAt: string;
  formattedLastLogin: string;
}

export function computeAccessValidity(createdAt: string, expiresAt: string): AccessValidityInfo {
  const now = new Date().getTime();
  const createdTime = new Date(createdAt).getTime();
  const expireTime = new Date(expiresAt).getTime();

  const totalDurationMs = expireTime - createdTime;
  const elapsedMs = Math.max(0, now - createdTime);
  const remainingMs = Math.max(0, expireTime - now);

  const MS_PER_DAY = 1000 * 60 * 60 * 24;
  const daysUsed = Math.min(365, Math.floor(elapsedMs / MS_PER_DAY));
  const daysRemaining = Math.max(0, Math.ceil(remainingMs / MS_PER_DAY));
  const isExpired = now >= expireTime || daysRemaining <= 0;

  const percentageUsed = totalDurationMs > 0 
    ? Math.min(100, Math.max(0, Math.round((elapsedMs / totalDurationMs) * 100))) 
    : 100;

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      return new Intl.DateTimeFormat('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }).format(d);
    } catch {
      return iso;
    }
  };

  return {
    daysUsed,
    daysRemaining,
    isExpired,
    percentageUsed,
    formattedExpiresAt: formatDate(expiresAt),
    formattedCreatedAt: formatDate(createdAt),
    formattedLastLogin: formatDate(new Date().toISOString()),
  };
}
