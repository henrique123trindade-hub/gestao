import React, { useEffect, useState } from 'react';
import {
  UserCheck,
  Clock,
  Calendar,
  LogOut,
  Shield,
  CheckCircle2,
  AlertTriangle,
  Radio,
  ExternalLink,
  Laptop,
} from 'lucide-react';
import { UserRecord, UserSession, computeAccessValidity } from '../types';
import { subscribeToUser } from '../userService';

interface UserPortalProps {
  session: UserSession;
  onLogout: () => void;
  onOpenAdminModal: () => void;
}

export const UserPortal: React.FC<UserPortalProps> = ({
  session,
  onLogout,
  onOpenAdminModal,
}) => {
  const [user, setUser] = useState<UserRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [bannedAlert, setBannedAlert] = useState(false);
  const [disconnectedAlert, setDisconnectedAlert] = useState(false);

  // Subscribe to real-time updates for this specific user
  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToUser(session.userId, (updatedUser) => {
      setLoading(false);
      if (!updatedUser) {
        // Account was deleted
        onLogout();
        return;
      }

      setUser(updatedUser);

      // Check real-time BAN (Requirement 7: "Quando for banido: Deve ser desconectado imediatamente.")
      if (updatedUser.status === 'banned') {
        setBannedAlert(true);
        setTimeout(() => {
          onLogout();
        }, 3500);
      }

      // Check real-time remote session disconnect
      if (updatedUser.sessionVersion > session.sessionVersion) {
        setDisconnectedAlert(true);
        setTimeout(() => {
          onLogout();
        }, 3000);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [session.userId, session.sessionVersion, onLogout]);

  if (loading && !user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 mx-auto border-3 border-amber-500/20 border-t-amber-600 rounded-full animate-spin" />
          <p className="text-xs font-semibold text-slate-600">Sincronizando conta com o banco de dados...</p>
        </div>
      </div>
    );
  }

  const validity = user
    ? computeAccessValidity(user.createdAt, user.expiresAt)
    : null;

  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-800 flex flex-col">
      {/* Real-time Banned Alert Modal */}
      {bannedAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-rose-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white border border-rose-200 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Acesso Bloqueado</h2>
              <p className="text-xs text-rose-600 mt-1 font-semibold">
                Sua conta foi banida pelo administrador em tempo real.
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Você está sendo desconectado do sistema imediatamente por violar os termos de uso.
              </p>
            </div>
            <div className="pt-2">
              <button
                onClick={onLogout}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors"
              >
                Encerrar Sessão Agora
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Real-time Remote Disconnect Alert Modal */}
      {disconnectedAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-amber-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white border border-amber-200 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Sessão Revogada</h2>
              <p className="text-xs text-amber-700 mt-1 font-semibold">
                Sua sessão ativa foi desconectada remotamente pelo administrador.
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Por motivos de segurança, você foi desconectado e precisará fazer login novamente.
              </p>
            </div>
            <div className="pt-2">
              <button
                onClick={onLogout}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition-colors"
              >
                Voltar ao Login
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Header */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-20 px-4 sm:px-6 py-3.5">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-sm">
              {user?.name.substring(0, 2).toUpperCase() || 'US'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
                  {user?.name}
                </h1>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Conta Ativa
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono">{user?.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenAdminModal}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <Shield className="w-3.5 h-3.5 text-amber-600" />
              <span>Painel Admin</span>
            </button>

            <button
              id="user-logout-btn"
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg shadow-sm transition-colors"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-500" />
              <span>Sair da Conta</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8 space-y-6">
        {/* Multi-Device Real-Time Sync Banner */}
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-700 shrink-0 mt-0.5">
              <Radio className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">
                Sincronização em Tempo Real Ativa com o Firestore
              </p>
              <p className="text-slate-600 mt-0.5">
                Esta conta funciona em qualquer dispositivo com e-mail e senha. Se o administrador banir ou revogar sua sessão no painel admin, você será desconectado instantaneamente.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenAdminModal}
            className="shrink-0 px-3 py-1.5 text-xs font-semibold text-amber-800 bg-amber-200/60 hover:bg-amber-200 rounded-xl transition-colors inline-flex items-center gap-1"
          >
            <span>Acessar Admin</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        {/* 365 Days Access Validity Card */}
        {validity && (
          <section className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                    <Clock className="w-4 h-4" />
                  </div>
                  <h2 className="text-base font-bold text-slate-900">
                    Período de Validade de Acesso (365 Dias)
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Cada conta possui validade máxima de 365 dias a partir da data de criação
                </p>
              </div>

              <div className="text-right">
                <span className="text-2xl font-black text-emerald-600">
                  {validity.daysRemaining}
                </span>
                <span className="text-xs font-medium text-slate-500 ml-1">dias restantes</span>
              </div>
            </div>

            {/* Visual Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span className="font-medium">Progresso do Período de Acesso</span>
                <span className="font-bold text-slate-800">
                  {validity.daysUsed} de 365 dias utilizados ({validity.percentageUsed}%)
                </span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200/60">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-700"
                  style={{ width: `${Math.max(2, validity.percentageUsed)}%` }}
                />
              </div>
            </div>

            {/* 3 Stat Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Data de Criação
                </span>
                <span className="text-xs font-bold text-slate-800">
                  {validity.formattedCreatedAt}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Data de Expiração (365d)
                </span>
                <span className="text-xs font-bold text-slate-800">
                  {validity.formattedExpiresAt}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Status de Validade
                </span>
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Acesso Válido
                </span>
              </div>
            </div>
          </section>
        )}

        {/* Account Details & Session Security */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Identity Info */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Laptop className="w-4 h-4 text-slate-600" />
              <span>Informações da Conta</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Nome Completo:</span>
                <span className="font-semibold text-slate-800">{user?.name}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">E-mail Cadastrado:</span>
                <span className="font-mono text-slate-800">{user?.email}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Identificador Firestore:</span>
                <span className="font-mono text-[11px] text-slate-600">{user?.id}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-500">Persistência:</span>
                <span className="font-semibold text-emerald-600">Em Nuvem (Google Firestore)</span>
              </div>
            </div>
          </div>

          {/* Session Security */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Shield className="w-4 h-4 text-slate-600" />
              <span>Segurança da Sessão</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Último Login Registrado:</span>
                <span className="font-semibold text-slate-800">
                  {user?.lastLoginAt
                    ? new Intl.DateTimeFormat('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      }).format(new Date(user.lastLoginAt))
                    : 'Nenhum'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Versão da Sessão:</span>
                <span className="font-mono font-semibold text-slate-800">
                  v{user?.sessionVersion}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Armazenamento de Senha:</span>
                <span className="font-semibold text-slate-700">Hash Criptográfico (SHA-256 + Salt)</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-500">Revogação Instantânea:</span>
                <span className="font-semibold text-emerald-600">Habilitada via Firestore Snapshot</span>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
