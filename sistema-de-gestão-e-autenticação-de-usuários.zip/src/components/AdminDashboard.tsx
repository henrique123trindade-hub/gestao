import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  UserCheck,
  UserX,
  Clock,
  Search,
  LogOut,
  Ban,
  RotateCcw,
  Wifi,
  Radio,
  ShieldAlert,
  Calendar,
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { UserRecord, computeAccessValidity } from '../types';
import {
  subscribeToAllUsers,
  banUser,
  unbanUser,
  disconnectUser,
} from '../userService';

interface AdminDashboardProps {
  onLogoutAdmin: () => void;
  onOpenUserPortalDemo?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onLogoutAdmin,
  onOpenUserPortalDemo,
}) => {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'banned' | 'expired'>('all');
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [selectedUserForDetails, setSelectedUserForDetails] = useState<UserRecord | null>(null);

  // Subscribe to real-time users collection
  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToAllUsers(
      (updatedUsers) => {
        setUsers(updatedUsers);
        setLoading(false);
        setLastSyncTime(new Date());
      },
      (error) => {
        console.error('Failed to stream users:', error);
        setLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Filtered users calculation
  const filteredUsers = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const now = Date.now();

    return users.filter((u) => {
      const matchesSearch =
        !query ||
        u.name.toLowerCase().includes(query) ||
        u.email.toLowerCase().includes(query);

      if (!matchesSearch) return false;

      if (statusFilter === 'all') return true;
      if (statusFilter === 'banned') return u.status === 'banned';

      const isExpired = now >= new Date(u.expiresAt).getTime();
      if (statusFilter === 'expired') return isExpired;
      if (statusFilter === 'active') return u.status === 'active' && !isExpired;

      return true;
    });
  }, [users, searchQuery, statusFilter]);

  // Metric indicators (Active, Banned, New, Expired)
  const metrics = useMemo(() => {
    const total = users.length;
    const now = Date.now();
    const oneDayAgo = now - 24 * 60 * 60 * 1000;

    let activeCount = 0;
    let bannedCount = 0;
    let newUsersCount = 0;
    let expiredCount = 0;

    users.forEach((u) => {
      const isExpired = now >= new Date(u.expiresAt).getTime();
      if (u.status === 'banned') {
        bannedCount++;
      } else if (isExpired) {
        expiredCount++;
      } else {
        activeCount++;
      }

      if (new Date(u.createdAt).getTime() >= oneDayAgo) {
        newUsersCount++;
      }
    });

    return {
      total,
      activeCount,
      bannedCount,
      newUsersCount,
      expiredCount,
    };
  }, [users]);

  // User Actions
  const handleBan = async (user: UserRecord) => {
    if (!window.confirm(`Tem certeza que deseja banir o usuário "${user.name}" (${user.email})? Ele será desconectado instantaneamente.`)) {
      return;
    }
    try {
      setActionInProgress(`ban_${user.id}`);
      await banUser(user.id);
      // Disconnect as well so session is instantly invalidated
      await disconnectUser(user.id);
      setNotification(`Usuário ${user.name} foi banido com sucesso e desconectado em tempo real.`);
    } catch (err: any) {
      alert(`Erro ao banir usuário: ${err.message}`);
    } finally {
      setActionInProgress(null);
      setTimeout(() => setNotification(null), 4000);
    }
  };

  const handleUnban = async (user: UserRecord) => {
    try {
      setActionInProgress(`unban_${user.id}`);
      await unbanUser(user.id);
      setNotification(`Usuário ${user.name} foi desbanido com sucesso e pode acessar novamente.`);
    } catch (err: any) {
      alert(`Erro ao desbanir usuário: ${err.message}`);
    } finally {
      setActionInProgress(null);
      setTimeout(() => setNotification(null), 4000);
    }
  };

  const handleDisconnect = async (user: UserRecord) => {
    try {
      setActionInProgress(`dc_${user.id}`);
      await disconnectUser(user.id);
      setNotification(`Sessão ativa de ${user.name} revogada remotamente em tempo real.`);
    } catch (err: any) {
      alert(`Erro ao desconectar usuário: ${err.message}`);
    } finally {
      setActionInProgress(null);
      setTimeout(() => setNotification(null), 4000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Administrative Bar */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-30 px-4 sm:px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  Painel Administrativo em Tempo Real
                </h1>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Firestore Live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Sincronização persistente de contas e sessões multi-dispositivo
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-400">
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              <span>Sincronizado: {lastSyncTime.toLocaleTimeString('pt-BR')}</span>
            </div>

            {onOpenUserPortalDemo && (
              <button
                id="open-user-portal-demo-btn"
                onClick={onOpenUserPortalDemo}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
                title="Abrir tela de usuário para testar sincronização"
              >
                <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                <span>Portal do Usuário</span>
              </button>
            )}

            <button
              id="logout-admin-btn"
              onClick={onLogoutAdmin}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-lg transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sair do Admin</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Floating Live Notification */}
        {notification && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 rounded-xl text-xs flex items-center justify-between gap-3 shadow-lg animate-in slide-in-from-top-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>{notification}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-emerald-400 hover:text-white font-bold"
            >
              &times;
            </button>
          </div>
        )}

        {/* Real-time Indicator Cards */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {/* Total Users */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-sm relative overflow-hidden group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-400">Total de Cadastros</span>
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-white">{metrics.total}</span>
              <span className="text-[11px] text-slate-500">contas</span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">Armazenadas no Firestore</p>
          </div>

          {/* Active Users */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-sm relative overflow-hidden group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-400">Contas Ativas</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <UserCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-emerald-400">{metrics.activeCount}</span>
              <span className="text-[11px] text-emerald-500/80">
                {metrics.total > 0 ? `${Math.round((metrics.activeCount / metrics.total) * 100)}%` : '0%'}
              </span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">Acesso liberado no sistema</p>
          </div>

          {/* Banned Users */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-sm relative overflow-hidden group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-400">Contas Banidas</span>
              <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center">
                <UserX className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-rose-400">{metrics.bannedCount}</span>
              <span className="text-[11px] text-rose-500/80">
                {metrics.total > 0 ? `${Math.round((metrics.bannedCount / metrics.total) * 100)}%` : '0%'}
              </span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">Bloqueadas pelo administrador</p>
          </div>

          {/* New Registrations (24h) */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-sm relative overflow-hidden group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-slate-400">Novos Usuários (24h)</span>
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-amber-400">{metrics.newUsersCount}</span>
              <span className="text-[11px] text-amber-500/80">hoje</span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">Cadastrados recentemente</p>
          </div>
        </section>

        {/* Search, Filter, and Controls Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="admin-search-users-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Pesquisar por nome ou e-mail em tempo real..."
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/30 transition-all"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'all'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Todos ({users.length})
            </button>
            <button
              onClick={() => setStatusFilter('active')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'active'
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Ativos ({metrics.activeCount})
            </button>
            <button
              onClick={() => setStatusFilter('banned')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'banned'
                  ? 'bg-rose-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Banidos ({metrics.bannedCount})
            </button>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-slate-200">
                Lista de Usuários Cadastrados
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-mono bg-slate-800 text-slate-400 rounded-md">
                {filteredUsers.length} {filteredUsers.length === 1 ? 'resultado' : 'resultados'}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>Validade máxima: 365 dias</span>
            </div>
          </div>

          {loading ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-8 h-8 mx-auto border-2 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
              <p className="text-xs text-slate-400">Carregando usuários do Firestore...</p>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="py-16 text-center space-y-2 px-4">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-500">
                <Users className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-300">Nenhum usuário encontrado</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {searchQuery
                  ? `Nenhum registro corresponde a "${searchQuery}".`
                  : 'Nenhum usuário cadastrado no banco de dados ainda. Crie uma conta no portal para ver o registro aparecer em tempo real.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/40 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-4">Usuário</th>
                    <th className="py-3 px-4">E-mail</th>
                    <th className="py-3 px-4">Cadastro</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Último Acesso</th>
                    <th className="py-3 px-4">Tempo de Acesso (365d)</th>
                    <th className="py-3 px-4 text-right">Ações de Controle</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs">
                  {filteredUsers.map((user) => {
                    const validity = computeAccessValidity(user.createdAt, user.expiresAt);
                    const isBanned = user.status === 'banned';
                    const isBusy = actionInProgress?.includes(user.id);

                    return (
                      <tr
                        key={user.id}
                        className={`hover:bg-slate-800/40 transition-colors ${
                          isBanned ? 'bg-rose-950/10' : ''
                        }`}
                      >
                        {/* Name & Avatar */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-amber-400 uppercase">
                              {user.name.substring(0, 2)}
                            </div>
                            <div>
                              <div className="font-medium text-slate-200">{user.name}</div>
                              <div className="text-[10px] font-mono text-slate-500">
                                ID: {user.id.substring(0, 10)}...
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Email */}
                        <td className="py-3.5 px-4">
                          <span className="font-mono text-slate-300">{user.email}</span>
                        </td>

                        {/* Created At */}
                        <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                          {validity.formattedCreatedAt}
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {isBanned ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                              Banido
                            </span>
                          ) : validity.isExpired ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                              <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
                              Expirado
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                              Ativo
                            </span>
                          )}
                        </td>

                        {/* Last Login */}
                        <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                          {user.lastLoginAt ? (
                            <div className="flex flex-col">
                              <span className="text-slate-300">
                                {new Intl.DateTimeFormat('pt-BR', {
                                  day: '2-digit',
                                  month: '2-digit',
                                  year: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                }).format(new Date(user.lastLoginAt))}
                              </span>
                              <span className="text-[10px] text-slate-500">Sessão v{user.sessionVersion}</span>
                            </div>
                          ) : (
                            'Nunca'
                          )}
                        </td>

                        {/* Access Validity (365 days max) */}
                        <td className="py-3.5 px-4">
                          <div className="w-48 space-y-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-semibold text-slate-200">
                                {validity.daysRemaining} dias restantes
                              </span>
                              <span className="text-slate-400 text-[10px]">
                                {validity.daysUsed} / 365d
                              </span>
                            </div>
                            {/* Progress bar */}
                            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-500 ${
                                  validity.isExpired
                                    ? 'bg-rose-500'
                                    : validity.daysRemaining < 30
                                    ? 'bg-amber-500'
                                    : 'bg-emerald-500'
                                }`}
                                style={{ width: `${Math.min(100, (validity.daysUsed / 365) * 100)}%` }}
                              />
                            </div>
                            <div className="text-[10px] text-slate-500">
                              Expira em: {validity.formattedExpiresAt}
                            </div>
                          </div>
                        </td>

                        {/* Control Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            {/* Ban / Unban Button */}
                            {isBanned ? (
                              <button
                                id={`unban-user-${user.id}-btn`}
                                onClick={() => handleUnban(user)}
                                disabled={isBusy}
                                className="px-2.5 py-1 text-xs font-semibold text-emerald-400 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/40 rounded-lg transition-colors inline-flex items-center gap-1"
                                title="Desbanir usuário e liberar acesso"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Desbanir</span>
                              </button>
                            ) : (
                              <button
                                id={`ban-user-${user.id}-btn`}
                                onClick={() => handleBan(user)}
                                disabled={isBusy}
                                className="px-2.5 py-1 text-xs font-semibold text-rose-400 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/40 rounded-lg transition-colors inline-flex items-center gap-1"
                                title="Banir usuário e desconectar imediatamente"
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>Banir</span>
                              </button>
                            )}

                            {/* Remote Disconnect Button */}
                            <button
                              id={`disconnect-user-${user.id}-btn`}
                              onClick={() => handleDisconnect(user)}
                              disabled={isBusy}
                              className="px-2.5 py-1 text-xs font-semibold text-amber-300 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/40 rounded-lg transition-colors inline-flex items-center gap-1"
                              title="Desconectar todas as sessões ativas deste usuário"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" />
                              <span>Desconectar</span>
                            </button>

                            {/* Details Button */}
                            <button
                              onClick={() => setSelectedUserForDetails(selectedUserForDetails?.id === user.id ? null : user)}
                              className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Ver detalhes da conta"
                            >
                              {selectedUserForDetails?.id === user.id ? (
                                <ChevronUp className="w-4 h-4" />
                              ) : (
                                <ChevronDown className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Selected User Detailed Drawer / Card */}
        {selectedUserForDetails && (
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
                  {selectedUserForDetails.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">{selectedUserForDetails.name}</h3>
                  <p className="text-xs text-slate-400">{selectedUserForDetails.email}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUserForDetails(null)}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                Fechar detalhes
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                <span className="text-slate-500 block mb-1">Identificador Único (UID)</span>
                <span className="font-mono text-slate-300 break-all">{selectedUserForDetails.id}</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                <span className="text-slate-500 block mb-1">Hash da Senha (Seguro SHA-256)</span>
                <span className="font-mono text-slate-400 break-all text-[10px]">
                  {selectedUserForDetails.passwordHash.substring(0, 32)}... (oculto)
                </span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60">
                <span className="text-slate-500 block mb-1">Versão de Sessão Token</span>
                <span className="font-semibold text-emerald-400">
                  Versão {selectedUserForDetails.sessionVersion} (Revogável)
                </span>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
