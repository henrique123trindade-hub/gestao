import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  query,
  where,
  onSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { generateSalt, hashPassword, verifyPassword } from './crypto';
import { UserRecord } from './types';

const USERS_COLLECTION = 'users';

/**
 * Register a new user in the persistent Firestore database.
 * Enforces email uniqueness, hashes password, assigns 365-day validity period.
 */
export async function registerUser(
  name: string,
  emailInput: string,
  passwordInput: string
): Promise<UserRecord> {
  const email = emailInput.trim().toLowerCase();
  const trimmedName = name.trim();

  if (!trimmedName) {
    throw new Error('O nome é obrigatório.');
  }

  if (!email || !email.includes('@')) {
    throw new Error('E-mail inválido.');
  }

  if (!passwordInput || passwordInput.length < 6) {
    throw new Error('A senha deve ter no mínimo 6 caracteres.');
  }

  // 1. Check for email duplication across all users
  const pathForQuery = USERS_COLLECTION;
  try {
    const q = query(collection(db, pathForQuery), where('email', '==', email));
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
      throw new Error('Este e-mail já está cadastrado no sistema. Escolha outro ou faça login.');
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes('já está cadastrado')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.LIST, pathForQuery);
  }

  // 2. Generate secure salted hash
  const salt = generateSalt(16);
  const passwordHash = await hashPassword(passwordInput, salt);

  // 3. Set up 365-day validity access window
  const now = new Date();
  const createdAt = now.toISOString();
  const expiresAt = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString();

  // Create document ID
  const userId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

  const newUser: UserRecord = {
    id: userId,
    name: trimmedName,
    email,
    passwordHash,
    passwordSalt: salt,
    createdAt,
    lastLoginAt: createdAt,
    status: 'active',
    sessionVersion: 1,
    maxAccessDays: 365,
    expiresAt,
  };

  // 4. Persist to Firestore
  try {
    await setDoc(doc(db, USERS_COLLECTION, userId), newUser);
    return newUser;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${USERS_COLLECTION}/${userId}`);
  }
}

/**
 * Authenticates user credentials with email and password.
 * Updates last login timestamp in real-time and verifies ban/expiration status.
 */
export async function loginUser(
  emailInput: string,
  passwordInput: string
): Promise<UserRecord> {
  const email = emailInput.trim().toLowerCase();

  if (!email || !passwordInput) {
    throw new Error('Preencha o e-mail e a senha.');
  }

  // Query user by email
  let userRecord: UserRecord | null = null;
  try {
    const q = query(collection(db, USERS_COLLECTION), where('email', '==', email));
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
      throw new Error('E-mail ou senha incorretos.');
    }
    const docSnap = querySnapshot.docs[0];
    userRecord = docSnap.data() as UserRecord;
    // ensure doc ID matches
    userRecord.id = docSnap.id;
  } catch (error) {
    if (error instanceof Error && (error.message.includes('incorretos') || error.message.includes('banida'))) {
      throw error;
    }
    handleFirestoreError(error, OperationType.GET, USERS_COLLECTION);
  }

  if (!userRecord) {
    throw new Error('Usuário não encontrado.');
  }

  // Verify password hash
  const isValid = await verifyPassword(passwordInput, userRecord.passwordSalt, userRecord.passwordHash);
  if (!isValid) {
    throw new Error('E-mail ou senha incorretos.');
  }

  // Check if banned
  if (userRecord.status === 'banned') {
    throw new Error('Esta conta foi banida pelo administrador. O acesso está bloqueado.');
  }

  // Check 365-day expiration
  const nowTime = Date.now();
  const expireTime = new Date(userRecord.expiresAt).getTime();
  if (nowTime >= expireTime) {
    throw new Error('O período máximo de 365 dias para esta conta expirou. Entre em contato com o suporte.');
  }

  // Update lastLoginAt in real-time
  const newLastLogin = new Date().toISOString();
  try {
    await updateDoc(doc(db, USERS_COLLECTION, userRecord.id), {
      lastLoginAt: newLastLogin,
    });
    userRecord.lastLoginAt = newLastLogin;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${USERS_COLLECTION}/${userRecord.id}`);
  }

  return userRecord;
}

/**
 * Ban a user by updating their status to 'banned'.
 */
export async function banUser(userId: string): Promise<void> {
  try {
    await updateDoc(doc(db, USERS_COLLECTION, userId), {
      status: 'banned',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${USERS_COLLECTION}/${userId}`);
  }
}

/**
 * Unban a user by updating their status to 'active'.
 */
export async function unbanUser(userId: string): Promise<void> {
  try {
    await updateDoc(doc(db, USERS_COLLECTION, userId), {
      status: 'active',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${USERS_COLLECTION}/${userId}`);
  }
}

/**
 * Remotely disconnects a user by incrementing their sessionVersion in Firestore.
 * Active sessions of that user listening via onSnapshot will be logged out immediately.
 */
export async function disconnectUser(userId: string): Promise<void> {
  try {
    const userRef = doc(db, USERS_COLLECTION, userId);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      throw new Error('Usuário não encontrado.');
    }
    const currentData = snap.data() as UserRecord;
    const nextVersion = (currentData.sessionVersion || 1) + 1;
    await updateDoc(userRef, {
      sessionVersion: nextVersion,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${USERS_COLLECTION}/${userId}`);
  }
}

/**
 * Real-time listener for all users (for administrative dashboard).
 * Triggers instant UI updates on any registration, login, ban, or disconnect across all devices.
 */
export function subscribeToAllUsers(
  onUpdate: (users: UserRecord[]) => void,
  onError?: (err: unknown) => void
): () => void {
  const usersCol = collection(db, USERS_COLLECTION);
  return onSnapshot(
    usersCol,
    snapshot => {
      const users: UserRecord[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data() as UserRecord;
        users.push({
          ...data,
          id: docSnap.id,
        });
      });
      // Sort with newest accounts first
      users.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onUpdate(users);
    },
    error => {
      console.error('Snapshot error for all users:', error);
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, USERS_COLLECTION);
    }
  );
}

/**
 * Real-time listener for an individual logged-in user.
 * Allows immediate reaction if the admin bans the user or revokes their session.
 */
export function subscribeToUser(
  userId: string,
  onUpdate: (user: UserRecord | null) => void,
  onError?: (err: unknown) => void
): () => void {
  const userDoc = doc(db, USERS_COLLECTION, userId);
  return onSnapshot(
    userDoc,
    docSnap => {
      if (docSnap.exists()) {
        const data = docSnap.data() as UserRecord;
        onUpdate({
          ...data,
          id: docSnap.id,
        });
      } else {
        onUpdate(null);
      }
    },
    error => {
      console.error('Snapshot error for user', userId, error);
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.GET, `${USERS_COLLECTION}/${userId}`);
    }
  );
}
