import React, { useState, useEffect } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { AdminDashboard } from './components/AdminDashboard';
import { UserPortal } from './components/UserPortal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { testConnection } from './firebase';
import { UserRecord, UserSession } from './types';

export default function App() {
  const [currentUserSession, setCurrentUserSession] = useState<UserSession | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);

  // Restore sessions and verify database connection on initial load
  useEffect(() => {
    // 1. Test Firestore online connectivity
    testConnection();

    // 2. Restore user session if stored in localStorage (Requirement 2: Recuperação segura da sessão)
    try {
      const storedUser = localStorage.getItem('app_user_session');
      if (storedUser) {
        const parsed: UserSession = JSON.parse(storedUser);
        if (parsed && parsed.userId && parsed.email) {
          setCurrentUserSession(parsed);
        }
      }
    } catch (err) {
      console.error('Failed to parse saved user session:', err);
      localStorage.removeItem('app_user_session');
    }

    // 3. Restore admin session if stored in sessionStorage
    try {
      const adminAuth = sessionStorage.getItem('isAdminAuthenticated');
      if (adminAuth === 'true') {
        setIsAdmin(true);
      }
    } catch (err) {
      console.error('Failed to restore admin session:', err);
    }

    setIsInitializing(false);
  }, []);

  const handleUserAuthSuccess = (user: UserRecord) => {
    const session: UserSession = {
      userId: user.id,
      name: user.name,
      email: user.email,
      sessionVersion: user.sessionVersion,
    };
    localStorage.setItem('app_user_session', JSON.stringify(session));
    setCurrentUserSession(session);
    // If admin was open, focus user experience
    setIsAdmin(false);
  };

  const handleUserLogout = () => {
    localStorage.removeItem('app_user_session');
    setCurrentUserSession(null);
  };

  const handleAdminAuthSuccess = () => {
    setIsAdmin(true);
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('isAdminAuthenticated');
    setIsAdmin(false);
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 mx-auto border-2 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
          <p className="text-xs text-slate-400 font-mono">Inicializando conexão com Firestore...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-950">
      {/* View router based on active session */}
      {isAdmin ? (
        <AdminDashboard
          onLogoutAdmin={handleAdminLogout}
          onOpenUserPortalDemo={() => {
            if (currentUserSession) {
              setIsAdmin(false);
            } else {
              setShowAdminModal(false);
              setIsAdmin(false);
            }
          }}
        />
      ) : currentUserSession ? (
        <UserPortal
          session={currentUserSession}
          onLogout={handleUserLogout}
          onOpenAdminModal={() => setShowAdminModal(true)}
        />
      ) : (
        <AuthScreen
          onAuthSuccess={handleUserAuthSuccess}
          onOpenAdminModal={() => setShowAdminModal(true)}
        />
      )}

      {/* Admin Password Modal */}
      <AdminLoginModal
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
        onSuccess={handleAdminAuthSuccess}
      />
    </div>
  );
}
